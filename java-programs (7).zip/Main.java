/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{
	public static void main(String[] args) {
	    int limit=100;
		for (int i =2 ;i <= limit ;i=i+1){
		    if (i % 2!=0);
		  System.out.println(i);
		}
	}
}


